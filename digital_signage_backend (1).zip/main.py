
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
from datetime import datetime

app = FastAPI()

devices = {}
media_library = {}
schedules = {}

class Device(BaseModel):
    id: str
    location: str

class MediaItem(BaseModel):
    id: str
    name: str
    url: str

class ScheduleEntry(BaseModel):
    device_id: str
    media_ids: List[str]
    start_time: datetime
    end_time: datetime

@app.post("/register_device")
def register_device(device: Device):
    devices[device.id] = device
    return {"message": "Device registered"}

@app.post("/upload_media")
def upload_media(media: MediaItem):
    media_library[media.id] = media
    return {"message": "Media uploaded"}

@app.post("/schedule_media")
def schedule_media(schedule: ScheduleEntry):
    if schedule.device_id not in devices:
        raise HTTPException(status_code=404, detail="Device not found")
    schedules[schedule.device_id] = schedule
    return {"message": "Media scheduled"}

@app.get("/get_schedule/{device_id}")
def get_schedule(device_id: str):
    if device_id not in schedules:
        raise HTTPException(status_code=404, detail="No schedule for this device")
    schedule = schedules[device_id]
    items = [media_library[mid] for mid in schedule.media_ids]
    return {"schedule": schedule, "media_items": items}
